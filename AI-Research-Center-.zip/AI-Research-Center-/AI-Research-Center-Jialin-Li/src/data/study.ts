export type StudyItem = { 
  slug: string; 
  title: string; 
  description: string; 
  details: string;
  link: string; 
  category: 'funded' | 'unfunded' | 'coursework'; 
};

export const study: StudyItem[] = [
  { 
    slug: 'phd-opportunities', 
    title: 'PhD Opportunities', 
    description: 'Work with supervisors in AI, CV, NLP, and HCI.', 
    details: '...', 
    link: '/study/phd-opportunities', 
    category: 'funded' 
  },
  { 
    slug: 'masters-honours', 
    title: 'Masters & Honours', 
    description: 'Coursework and research pathways available.', 
    details: '...',
    link: '/study/masters-honours',
    category: 'coursework'
  },
  { 
    slug: 'scholarships', 
    title: 'Scholarships', 
    description: 'Funding support for high-achieving students.', 
    details: '...',
    link: '/study/scholarships',
    category: 'funded'
  },
];